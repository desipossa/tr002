# Gnuboard5 Security Policy

Please ask [https://sir.kr/security/.](https://sir.kr/co_qa)
