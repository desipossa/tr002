$(function () {
    const main_visual_slide = new Swiper('.main_visual_slide', {
        loop: true,
    })
})